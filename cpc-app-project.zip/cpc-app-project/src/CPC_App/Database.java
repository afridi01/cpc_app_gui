
package CPC_App;
import java.sql.*;
import javax.swing.JOptionPane;
public class Database {
    Connection conn;
    public static Connection javadb(){
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cpc?zeroDateTimeBehavior=convertToNull","root","");
          // JOptionPane.showMessageDialog(null,"connected");
            return conn;
            
            
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Not connected");
            return null;
            
        }    
        
    }
}
