
package CPC_App;

import java.sql.*;
import javax.swing.JOptionPane;

public class TakeOffToken extends javax.swing.JFrame {
    Connection conn;
    ResultSet rs;
    PreparedStatement pst;
    
    public TakeOffToken() {
        initComponents();
         conn = Database.javadb();
        table();
    }
            public void table(){
    try{
        String sql="select * from takeoff";
          pst=conn.prepareStatement(sql);
          rs=pst.executeQuery();
         
    }
    catch(Exception e)
    {
         JOptionPane.showMessageDialog(null,e);
    }
}

    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        Year = new javax.swing.JComboBox();
        Name = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        ID = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        PhoneNo = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        Dept = new javax.swing.JComboBox();
        TShirt = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        SemesterC = new javax.swing.JComboBox();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jLabel7 = new javax.swing.JLabel();
        Done = new javax.swing.JButton();
        jTextField5 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        choice1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        setSize(new java.awt.Dimension(700, 480));

        jPanel1.setBackground(new java.awt.Color(243, 102, 40));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Name ");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 40, 20));

        jTextField1.setBackground(new java.awt.Color(52, 162, 198));
        jTextField1.setFont(new java.awt.Font("Sitka Subheading", 1, 32)); // NOI18N
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.setText("DIU CPC TAKE OFF PROGRAMING CONTEST");
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 670, 40));

        Year.setBackground(new java.awt.Color(52, 162, 198));
        Year.setFont(new java.awt.Font("Microsoft New Tai Lue", 1, 14)); // NOI18N
        Year.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Spring 20", "Summer 20", "Fall 20", " " }));
        Year.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                YearActionPerformed(evt);
            }
        });
        jPanel1.add(Year, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 40, 100, 30));
        Year.getAccessibleContext().setAccessibleName("");
        Year.getAccessibleContext().setAccessibleDescription("");

        Name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NameActionPerformed(evt);
            }
        });
        jPanel1.add(Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 100, 200, 20));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("ID  ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 30, -1));

        ID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IDActionPerformed(evt);
            }
        });
        jPanel1.add(ID, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, 150, -1));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Phone no");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 60, -1));

        PhoneNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PhoneNoActionPerformed(evt);
            }
        });
        jPanel1.add(PhoneNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, 150, -1));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Dept.");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 150, 30, 20));

        Dept.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Dept.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "CSE", "SWE", "EEE" }));
        jPanel1.add(Dept, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 150, -1, -1));

        TShirt.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        TShirt.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "S", "M", "L", "XL", "XXL", "XXXL" }));
        jPanel1.add(TShirt, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 200, -1, -1));

        jLabel5.setText("T-Shirt Size");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(434, 200, 60, 20));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Semester");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, -1, -1));

        SemesterC.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1st", "2nd" }));
        SemesterC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SemesterCActionPerformed(evt);
            }
        });
        jPanel1.add(SemesterC, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 270, -1, -1));

        jRadioButton1.setText("Bkash");
        jPanel1.add(jRadioButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 340, -1, -1));

        jRadioButton2.setText("Rocket");
        jPanel1.add(jRadioButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 340, -1, -1));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setText("Payment");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 340, 70, 20));

        Done.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Done.setText("Done");
        Done.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DoneActionPerformed(evt);
            }
        });
        jPanel1.add(Done, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 340, -1, -1));

        jTextField5.setEditable(false);
        jTextField5.setBackground(new java.awt.Color(243, 102, 40));
        jTextField5.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTextField5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField5.setText("Daffodil International University");
        jPanel1.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 40, 380, -1));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Serial ");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 40, 20));
        jPanel1.add(choice1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 60, 70, -1));

        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton1.setText("HOME");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 403, 270, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 665, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void YearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_YearActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_YearActionPerformed

    private void NameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NameActionPerformed

    private void PhoneNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PhoneNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PhoneNoActionPerformed

    private void SemesterCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SemesterCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SemesterCActionPerformed

    private void DoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoneActionPerformed
        // TODO add your handling code here:
       //JOptionPane.showMessageDialog(null, "Registration Compleate");
       // TakeOffToken tot = new TakeOffToken();
        
       this.setVisible(false);
       new Token_StudentCopy().setVisible(true);
       
       
       
         String sql= "Insert into takeoff(Serial,Name,ID,PhoneNo,Semester,Dept,TShirtSize,Year,Payment,Payment1)values(?,?,?,?,?,?,?,?,?,?)";
        try{
            pst = conn.prepareStatement(sql);
            pst.setString(1,choice1.getText());
            pst.setString(2,Name.getText());
            pst.setString(3,ID.getText());
            pst.setString(4,PhoneNo.getText());
            pst.setString(5,(String)SemesterC.getSelectedItem());
            pst.setString(6,(String)Dept.getSelectedItem());            
            pst.setString(7,(String)TShirt.getSelectedItem());
            pst.setString(8,(String)Year.getSelectedItem());
            pst.setString(9,(String)jRadioButton1.getText());
            pst.setString(10,(String)jRadioButton2.getText());
            pst.execute();
            JOptionPane.showMessageDialog(null,"infomation save");
            
        }catch(Exception e){
        
            JOptionPane.showMessageDialog(null,"Not Connected");
        }
    }//GEN-LAST:event_DoneActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     
       this.setVisible(false);
       new CPC_HOME().setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void IDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IDActionPerformed
        // TODO add your handling code here:
        TakeOffToken tok = new TakeOffToken();
        
    }//GEN-LAST:event_IDActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TakeOffToken.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TakeOffToken.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TakeOffToken.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TakeOffToken.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TakeOffToken().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox Dept;
    private javax.swing.JButton Done;
    private javax.swing.JTextField ID;
    private javax.swing.JTextField Name;
    private javax.swing.JTextField PhoneNo;
    private javax.swing.JComboBox SemesterC;
    private javax.swing.JComboBox TShirt;
    private javax.swing.JComboBox Year;
    private javax.swing.JTextField choice1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
}
